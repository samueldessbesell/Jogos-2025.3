import java.util.Scanner;

public class Historia {
    public static void mostrar(Scanner sc) {
        System.out.println("\n=== História ===");
        System.out.println("Em um mundo distante, onde a magia e as espadas\n" +
                           "moldam o destino das pessoas, um herói se ergue.\n" +
                           "Movido pela coragem e pela necessidade de proteger\n" +
                           "sua terra natal, ele deve enfrentar inimigos poderosos.\n" +
                           "Somente superando os desafios poderá restaurar a paz.");
        System.out.println("\nPressione ENTER para voltar ao menu.");
        sc.nextLine();
    }
}